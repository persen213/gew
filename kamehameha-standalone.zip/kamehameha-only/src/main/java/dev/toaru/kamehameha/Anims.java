package dev.toaru.kamehameha;

import dev.toaru.kamehameha.net.AnimMsg;
import dev.toaru.kamehameha.net.Net;
import javax.annotation.Nullable;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.PacketDistributor;

public final class Anims {
    private Anims() { }
    public static final int STOP = 0,
            KAMEHAMEHA = 1;
    // The PlayerAnimator pose resource is disabled until its format is verified against the installed library.
    private static final String[] NAMES = {null, null};

    public static @Nullable String name(int id) { return id > 0 && id < NAMES.length ? NAMES[id] : null; }

    public static void play(@Nullable ServerPlayer p, int anim) {
        if (p == null) return;
        Net.CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> p), new AnimMsg(p.getId(), anim));
    }
}