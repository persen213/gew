package dev.toaru.kamehameha.client;

import dev.toaru.kamehameha.Cfg;
import dev.toaru.kamehameha.ClientCfg;
import dev.toaru.kamehameha.net.FxType;
import dev.toaru.kamehameha.net.FxStartMsg;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

/** Draws all Kamehameha visual effects. Uses Level 3 Geo pattern. */
public final class FxRenderer {
    private FxRenderer() { }

    public static void draw(Geo glow, Camera camera, long now, float partial, double time) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        Vec3 cam = camera.getPosition();
        float opacity = ClientCfg.otherOpacity();

        for (ClientFx.Effect e : ClientFx.ACTIVE.values()) {
            if (!e.live(now)) continue;
            double prog = Math.min(1.0, e.age(now, partial) / (double) e.duration);
            if (prog <= 0) continue;

            // Skip far effects
            if (e.pos.distanceToSqr(cam) > 160 * 160) continue;

            Geo g = glow;
            boolean isSelf = mc.player != null && e.a == mc.player.getId();
            g.alphaScale = isSelf ? 1.0f : opacity;
            try {
                switch (e.type) {
                    case KAMEHAMEHA_CHARGE -> drawKamehamehaCharge(g, e, prog, time);
                    case KAMEHAMEHA_BEAM -> drawKamehamehaBeam(g, e, prog, time);
                }
            } catch (RuntimeException ex) {
                // Rendering is cosmetic; one malformed effect must never take down the render tick.
                dev.toaru.kamehameha.Kamehameha.LOGGER.warn("Skipping failed Kamehameha visual {}", e.type, ex);
            } finally {
                g.alphaScale = 1.0f;
            }
        }
    }

    // ============ KAMEHAMEHA BEAM ============

    /** Charging energy at caster's hands - swirling blue energy gathering. */
    private static void drawKamehamehaCharge(Geo g, ClientFx.Effect e, double prog, double time) {
        double pulse = 0.5 + 0.5 * Math.sin(time * 1.2);
        double r = e.power * (0.3 + 0.7 * prog);

        // Core charge sphere
        g.softFacing(e.pos, r, 32, 0xFF002060, 0xCC0040A0);
        g.softFacing(e.pos, r * 0.7, 24, 0xFF004080, 0xCC0080C0);
        g.softFacing(e.pos, r * 0.4, 16, 0xFF80C0FF, 0xCCA0D0FF);

        // Swirling energy ribbons converging
        for (int i = 0; i < 5; i++) {
            double phase = time * 0.25 + i * Math.PI * 2.0 / 5.0;
            double r1 = r * (1.5 - prog * 0.5);
            double r2 = r * 0.3;
            Vec3 p1 = e.pos.add(Math.cos(phase) * r1, Math.sin(phase * 1.7) * r1 * 0.5, Math.sin(phase) * r1);
            Vec3 p2 = e.pos.add(Math.cos(phase + time * 0.1) * r2, Math.sin(phase * 1.7 + time * 0.1) * r2 * 0.5, Math.sin(phase + time * 0.1) * r2);
            g.color(0.2f, 0.5f, 1f, (float) (0.6 * (1.0 - prog * 0.3)));
            g.ribbon(p1, p2, 0.05 * (1.0 - prog * 0.5));
        }

        // Outer pulsing ring
        g.color(0.3f, 0.6f, 1f, (float) (0.4 * pulse * prog));
        g.ring(e.pos, new Vec3(0, 1, 0), r * 1.8 * pulse, 0.05, 24, time * 0.5, true);
    }

    /** Active beam - blue cylindrical energy blast. */
    private static void drawKamehamehaBeam(Geo g, ClientFx.Effect e, double prog, double time) {
        Vec3 dir = e.aux.normalize();
        double range = Cfg.KM_RANGE.get();
        double radius = e.power;
        double beamProg = Math.min(1.0, prog * 3.0); // Beam extends quickly

        // Beam core - bright center
        Vec3 end = e.pos.add(dir.scale(range * beamProg));
        Vec3 mid = e.pos.add(dir.scale(range * beamProg * 0.5));

        // Central bright cylinder using soft-facing discs along the beam
        for (int i = 0; i < 20; i++) {
            double t = (i + 0.5) / 20.0;
            Vec3 p = e.pos.add(dir.scale(range * beamProg * t));
            double w = radius * (0.8 + 0.4 * Math.sin(time * 0.4 + t * Math.PI * 4.0));
            int coreColor = (t < 0.3) ? 0xFF80C0FF : (t < 0.7 ? 0xFF0080FF : 0xFF0040A0);
            int edgeColor = (t < 0.3) ? 0xCCA0D0FF : (t < 0.7 ? 0xCC00A0FF : 0xCC0060C0);
            g.softFacing(p, w, 16, coreColor, edgeColor);
        }

        // Outer energy sheath - spiraling ribbons
        for (int arm = 0; arm < 3; arm++) {
            double armPhase = time * 0.3 + arm * Math.PI * 2.0 / 3.0;
            for (int seg = 0; seg < 15; seg++) {
                double t0 = seg / 15.0;
                double t1 = (seg + 1) / 15.0;
                if (t1 > beamProg) break;
                double ang0 = armPhase + t0 * Math.PI * 8.0;
                double ang1 = armPhase + t1 * Math.PI * 8.0;
                double w0 = radius * 1.2 * (1.0 - t0 * 0.3);
                double w1 = radius * 1.2 * (1.0 - t1 * 0.3);
                Vec3 perp = (dir.y != 0 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0)).cross(dir).normalize();
                Vec3 p0 = e.pos.add(dir.scale(range * t0)).add(perp.scale(Math.cos(ang0) * w0));
                Vec3 p1 = e.pos.add(dir.scale(range * t1)).add(perp.scale(Math.cos(ang1) * w1));
                g.color(0.4f, 0.7f, 1f, (float) (0.5 * (1.0 - t0)));
                g.ribbon(p0, p1, 0.04);
            }
        }

        // Impact flash at end
        if (beamProg >= 1.0) {
            double flash = 0.5 + 0.5 * Math.sin(time * 0.8);
            g.softFacing(end, radius * 2.5 * flash, 24, 0xFFFFFFFF, 0xCC80C0FF);
            g.color(1f, 1f, 1f, (float) (0.3 * flash));
            g.ring(end, dir, radius * 3.0 * flash, radius * 0.2, 24, 0, true);
        }
    }
}