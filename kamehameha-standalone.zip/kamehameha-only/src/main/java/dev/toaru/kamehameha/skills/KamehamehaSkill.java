package dev.toaru.kamehameha.skills;

import dev.toaru.kamehameha.*;
import dev.toaru.kamehameha.net.Fx;
import dev.toaru.kamehameha.net.FxType;
import io.github.pinchan4273.reacademycraft.api.AbilityId;
import io.github.pinchan4273.reacademycraft.api.ActivationOutcome;
import io.github.pinchan4273.reacademycraft.api.TargetRelation;
import io.github.pinchan4273.reacademycraft.api.mc.AbilityActor;
import io.github.pinchan4273.reacademycraft.api.mc.ActivationContext;
import io.github.pinchan4273.reacademycraft.api.mc.AcademySafety;
import io.github.pinchan4273.reacademycraft.api.mc.SkillBehavior;
import java.util.List;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Server-authoritative Kamehameha beam ability.
 * Two stages: charge (1.5s default) -> beam (2s default).
 * Beam deals damage per tick to entities in a narrow cylinder.
 */
public final class KamehamehaSkill implements SkillBehavior {
    @Override public ActivationOutcome start(ActivationContext c) {
        ServerPlayer player = c.naturalUser();
        if (player == null) return ActivationOutcome.REFUSED_INVALID;
        if (Timed.ownedBy(Charge.class, player.getUUID()) != null || Timed.ownedBy(Beam.class, player.getUUID()) != null)
            return ActivationOutcome.REFUSED_INVALID;

        ServerLevel level = player.serverLevel();
        Vec3 eye = player.getEyePosition();
        Vec3 direction = player.getLookAngle();

        if (!c.pay(Cfg.f(Cfg.KM_CP), Cfg.f(Cfg.KM_OVERLOAD))) return ActivationOutcome.REFUSED_RESOURCE;
        c.setCooldown(Cfg.ticks(Cfg.KM_COOLDOWN));
        c.addProficiency(0.02f);

        int chargeTicks = Cfg.ticks(Cfg.KM_CHARGE);
        int beamTicks = Cfg.ticks(Cfg.KM_BEAM_DURATION);

        // Charge visual at caster's hands
        Vec3 chargePos = eye.add(direction.scale(1.2));
        Fx.make(level, chargePos, FxType.KAMEHAMEHA_CHARGE, chargeTicks)
                .a(player.getId()).power(Cfg.f(Cfg.KM_RADIUS)).range(128).send();
        Timed.add(new Charge(player, c.actor(), c.skill(), chargePos, direction, chargeTicks, beamTicks));
        Snd.kamehamehaCharge(level, chargePos);
        Anims.play(player, Anims.KAMEHAMEHA); // reuse pose
        return ActivationOutcome.PERFORMED;
    }

    private static final class Charge extends Timed.Effect {
        private final AbilityId skill;
        private final Vec3 startPos;
        private final Vec3 direction;
        private final int beamTicks;

        Charge(ServerPlayer owner, AbilityActor actor, AbilityId skill, Vec3 startPos, Vec3 direction,
               int chargeTicks, int beamTicks) {
            super(owner, actor, chargeTicks);
            this.skill = skill; this.startPos = startPos; this.direction = direction; this.beamTicks = beamTicks;
        }

        @Override protected boolean tick() {
            if (over()) {
                // Transition to beam
                Vec3 beamStart = startPos.add(direction.scale(0.5));
                Timed.add(new Beam(owner, actor, skill, beamStart, direction, beamTicks));
                Fx.make(level, beamStart, FxType.KAMEHAMEHA_BEAM, beamTicks)
                        .aux(direction).a(owner.getId()).power(Cfg.f(Cfg.KM_RADIUS)).range(128).send();
                Snd.kamehamehaBeam(level, beamStart);
                return false;
            }
            return true;
        }
    }

    private static final class Beam extends Timed.Effect {
        private final AbilityId skill;
        private final Vec3 origin;
        private final Vec3 direction;
        private final double range;
        private final double radius;
        private final int tickInterval;
        private long nextDamageAt;

        Beam(ServerPlayer owner, AbilityActor actor, AbilityId skill, Vec3 origin, Vec3 direction, int beamTicks) {
            super(owner, actor, beamTicks);
            this.skill = skill; this.origin = origin; this.direction = direction.normalize();
            this.range = Cfg.KM_RANGE.get(); this.radius = Cfg.KM_RADIUS.get();
            this.tickInterval = Cfg.ticks(Cfg.KM_TICK_RATE);
            this.nextDamageAt = level.getGameTime();
        }

        @Override protected boolean tick() {
            if (over()) return false;
            long now = level.getGameTime();
            if (now < nextDamageAt) return true;
            nextDamageAt = now + tickInterval;

            // Cylinder sweep: check entities along the beam path
            Vec3 end = origin.add(direction.scale(range));
            AABB beamBox = new AABB(origin.x, origin.y, origin.z, end.x, end.y, end.z).inflate(radius);
            List<LivingEntity> targets = level.getEntitiesOfClass(LivingEntity.class, beamBox,
                    e -> e.isAlive() && affectable(e, actor, skill, owner));

            for (LivingEntity target : targets) {
                // Check if target is actually within the beam cylinder
                Vec3 toTarget = target.position().subtract(origin);
                double proj = toTarget.dot(direction);
                if (proj < 0 || proj > range) continue;
                Vec3 closest = origin.add(direction.scale(proj));
                if (target.position().distanceTo(closest) > radius) continue;

                // Apply damage
                double damage = Cfg.KM_DAMAGE.get() * Resist.damageFactor(target);
                AcademySafety.attack(actor, target, skill, (float) damage);

                // Knockback along beam direction
                double kb = Cfg.KM_KNOCKBACK.get();
                if (kb > 0) {
                    target.setDeltaMovement(target.getDeltaMovement().add(direction.scale(kb)));
                    target.hurtMarked = true;
                }

                // Stop on first hit if not piercing
                if (!Cfg.b(Cfg.KM_PIERCING)) break;
            }
            return true;
        }
    }

    private static boolean affectable(LivingEntity target, AbilityActor actor, AbilityId skill, ServerPlayer owner) {
        if (!target.isAlive() || Resist.immune(target)) return false;
        if (target == owner && !Cfg.b(Cfg.KM_AFFECT_CASTER)) return false;
        if (target instanceof ServerPlayer && !Cfg.b(Cfg.KM_AFFECT_PLAYERS)) return false;
        TargetRelation relation = AcademySafety.relation(actor, target);
        if (relation == TargetRelation.SELF) return Cfg.b(Cfg.KM_AFFECT_CASTER);
        if (relation == TargetRelation.ALLY) return Cfg.b(Cfg.KM_AFFECT_ALLIES);
        return Targeting.hostile(actor, target, skill);
    }
}