package dev.toaru.kamehameha;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;

public final class Snd {
    private Snd() { }

    public static void at(ServerLevel level, Vec3 pos, net.minecraft.sounds.SoundEvent event, float volume, float pitch) {
        level.playSound(null, pos.x, pos.y, pos.z, event, SoundSource.PLAYERS, volume, pitch);
    }

    // Kamehameha
    public static void kamehamehaCharge(ServerLevel level, Vec3 pos) { at(level, pos, SoundEvents.BEACON_POWER_SELECT, 0.6f, 0.4f); }
    public static void kamehamehaBeam(ServerLevel level, Vec3 pos) { at(level, pos, SoundEvents.ENDER_DRAGON_GROWL, 0.8f, 0.5f); }
}