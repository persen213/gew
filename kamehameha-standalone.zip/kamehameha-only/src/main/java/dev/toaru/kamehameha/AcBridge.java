package dev.toaru.kamehameha;

import java.lang.reflect.Method;
import java.util.function.BooleanSupplier;
import javax.annotation.Nullable;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.common.capabilities.Capability;

/** Reflection bridge to Re:AcademyCraft internals (ability, level, category, interference). */
public final class AcBridge {
    private AcBridge() { }
    private static boolean tried, ok;
    private static Object cap;
    private static Method hasAbility, getLevel, addInterference, getAbility;

    private static synchronized void init() {
        if (tried) return;
        tried = true;
        try {
            Class<?> caps = Class.forName("io.github.pinchan4273.reacademycraft.capability.AbilityCapabilities");
            cap = caps.getField("PLAYER_ABILITY").get(null);
            Class<?> data = Class.forName("io.github.pinchan4273.reacademycraft.skill.PlayerAbilityData");
            hasAbility = data.getMethod("hasAbility");
            getLevel = data.getMethod("getLevel");
            addInterference = data.getMethod("addInterference", String.class, BooleanSupplier.class);
            try { getAbility = data.getMethod("getAbility"); } catch (Throwable t) { getAbility = null; }
            ok = cap instanceof Capability<?>;
        } catch (Throwable t) {
            Kamehameha.LOGGER.warn("Kamehameha: Re:AcademyCraft ability data could not be read ({})", t.toString());
        }
    }

    @SuppressWarnings("unchecked")
    private static @Nullable Object data(ServerPlayer p) {
        init();
        if (!ok) return null;
        try { return p.getCapability((Capability<Object>) cap).resolve().orElse(null); } catch (Throwable t) { return null; }
    }

    public static @Nullable Boolean esper(ServerPlayer p) {
        Object d = data(p); if (d == null) return null;
        try { return (Boolean) hasAbility.invoke(d); } catch (Throwable t) { return null; }
    }

    public static int level(ServerPlayer p) {
        Object d = data(p); if (d == null) return 0;
        try { return (Integer) getLevel.invoke(d); } catch (Throwable t) { return 0; }
    }

    public static boolean interfere(ServerPlayer p, String id, BooleanSupplier lasts) {
        Object d = data(p); if (d == null) return false;
        try { addInterference.invoke(d, id, lasts); return true; } catch (Throwable t) { return false; }
    }

    public static @Nullable String category(ServerPlayer p) {
        Object d = data(p); if (d == null || getAbility == null) return null;
        try { Object id = getAbility.invoke(d); return id == null ? null : id.toString(); } catch (Throwable t) { return null; }
    }
}