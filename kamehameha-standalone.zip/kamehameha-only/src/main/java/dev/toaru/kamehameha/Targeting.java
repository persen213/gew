package dev.toaru.kamehameha;

import io.github.pinchan4273.reacademycraft.api.AbilityId;
import io.github.pinchan4273.reacademycraft.api.mc.AbilityActor;
import io.github.pinchan4273.reacademycraft.api.mc.AcademySafety;
import javax.annotation.Nullable;
import java.util.Comparator;
import java.util.List;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.ClipContext;

/** Crosshair ray and hostiles via AcademySafety. */
public final class Targeting {
    private Targeting() { }

    public static @Nullable LivingEntity living(ServerPlayer p, double range) {
        Vec3 from = p.getEyePosition();
        Vec3 to = from.add(p.getLookAngle().scale(range));
        ServerLevel level = p.serverLevel();
        BlockHitResult clip = level.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        double maxDist = clip.getType() == HitResult.Type.BLOCK ? Math.sqrt(clip.getBlockPos().distSqr(p.blockPosition())) : range;
        List<LivingEntity> candidates = p.level().getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(maxDist),
                e -> e != p && !(e instanceof ArmorStand) && e.isAlive());
        candidates.sort(Comparator.comparingDouble(e -> e.distanceToSqr(p)));
        for (LivingEntity e : candidates) {
            Vec3 dir = e.position().subtract(from).normalize();
            if (p.getLookAngle().dot(dir) > 0.98) return e;
        }
        return null;
    }

    public static List<LivingEntity> livingWithin(ServerLevel level, Vec3 center, double radius, @Nullable Entity exclude) {
        AABB box = new AABB(center.x - radius, center.y - radius, center.z - radius, center.x + radius, center.y + radius, center.z + radius);
        return level.getEntitiesOfClass(LivingEntity.class, box, e -> e != exclude && e.isAlive() && !(e instanceof ArmorStand));
    }

    public static boolean hostile(AbilityActor actor, LivingEntity target, AbilityId skill) {
        var relation = AcademySafety.relation(actor, target);
        if (relation == io.github.pinchan4273.reacademycraft.api.TargetRelation.SELF
                || relation == io.github.pinchan4273.reacademycraft.api.TargetRelation.ALLY
                || relation == io.github.pinchan4273.reacademycraft.api.TargetRelation.NONE) return false;
        return AcademySafety.mayAttack(actor, target, skill);
    }

    public static boolean bossLike(LivingEntity e) {
        String t = e.getType().toString();
        if (t.contains("warden") || t.contains("ender_dragon") || t.contains("wither")) return true;
        return e.getMaxHealth() >= 200.0;
    }
}