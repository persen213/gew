package dev.toaru.kamehameha;

import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.common.ForgeConfigSpec.ConfigValue;
import net.minecraftforge.common.ForgeConfigSpec.DoubleValue;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.config.ModConfig;

/** Per-player visual settings (kamehameha-client.toml). */
public final class ClientCfg {
    private ClientCfg() { }
    private static final ForgeConfigSpec.Builder B = new ForgeConfigSpec.Builder();

    private static DoubleValue d(String name, double def, double min, double max) { return B.defineInRange(name, def, min, max); }

    // Visual quality: 0 = low, 1 = medium, 2 = high
    public static final DoubleValue QUALITY = d("quality", 2, 0, 2);
    // Opacity of OTHER players' Kamehameha effects
    public static final DoubleValue OTHER_OPACITY = d("other_opacity", 0.7, 0.0, 1.0);

    public static final ForgeConfigSpec SPEC = B.build();

    public static int quality() { try { return (int) Math.round(QUALITY.get()); } catch (RuntimeException e) { return 2; } }
    public static float otherOpacity() { try { return OTHER_OPACITY.get().floatValue(); } catch (RuntimeException e) { return 0.7f; } }

    public static void register() { ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, SPEC); }
}