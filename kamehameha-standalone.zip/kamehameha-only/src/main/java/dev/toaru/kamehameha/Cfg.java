package dev.toaru.kamehameha;

import java.util.List;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.common.ForgeConfigSpec.ConfigValue;
import net.minecraftforge.common.ForgeConfigSpec.DoubleValue;

/** Server-authoritative balance settings in kamehameha-common.toml. */
public final class Cfg {
    private Cfg() { }
    private static final ForgeConfigSpec.Builder B = new ForgeConfigSpec.Builder();
    private static DoubleValue d(String name, double def, double min, double max) { return B.defineInRange(name, def, min, max); }
    private static DoubleValue sec(String name, double def, double max) { return d(name, def, 0.05, max); }
    private static void push(String name, String comment) { B.comment(comment).push(name); }

    static { push("general", "Shared targeting and resistance settings."); }
    public static final DoubleValue RANGE = d("aim_range", 32.0, 4.0, 96.0);
    public static final DoubleValue MAX_DISTANCE = d("control_breaks_beyond_distance", 64.0, 8.0, 256.0);

    static { B.pop(); push("resistance", "Resistance multipliers for player categories and strong mobs."); }
    public static final DoubleValue STRONG_MOB_HEALTH = d("strong_mob_min_health", 100.0, 1.0, 100000.0);
    public static final DoubleValue STRONG_MOB_FACTOR = d("strong_mob_factor", 0.5, 0.0, 1.0);
    public static final DoubleValue BOSS_FACTOR = d("boss_factor", 0.25, 0.0, 1.0);
    public static final DoubleValue PLAYER_LEVEL_RESIST = d("player_resist_per_ability_level", 0.12, 0.0, 0.3);
    public static final DoubleValue PLAYER_MIN_FACTOR = d("player_min_factor", 0.3, 0.0, 1.0);
    public static final DoubleValue ELECTRO_FACTOR = d("electromaster_factor", 0.25, 0.0, 1.0);
    public static final DoubleValue VEC_FACTOR = d("vector_manipulator_factor", 0.0, 0.0, 1.0);
    public static final ConfigValue<List<? extends String>> ELECTRO_CATEGORIES = B.defineList("electromaster_categories", List.of("academy:electromaster"), x -> x instanceof String);
    public static final ConfigValue<List<? extends String>> VEC_CATEGORIES = B.defineList("vector_manipulator_categories", List.of("academy:vecmanip"), x -> x instanceof String);
    public static final ConfigValue<String> IMMUNE_TAG = B.define("immune_player_tag", "imagine_breaker");

    static { B.pop(); push("breaking_free", "Retained for compatibility with earlier configs."); }
    public static final DoubleValue STRUGGLE_BASE = d("presses_needed", 14.0, 1.0, 200.0);
    public static final DoubleValue STRUGGLE_PER_LEVEL = d("fewer_presses_per_ability_level", 2.0, 0.0, 20.0);
    public static final DoubleValue STRUGGLE_MIN = d("min_presses_needed", 4.0, 1.0, 200.0);
    public static final DoubleValue BIG_HIT = d("big_hit_damage", 6.0, 0.5, 1000.0);
    public static final DoubleValue BIG_HIT_CUT = d("big_hit_removes_fraction_of_time_left", 0.4, 0.0, 1.0);

    static { B.pop(); push("kamehameha", "Kamehameha beam ability. All gameplay values are server-side and configurable."); }
    public static final DoubleValue KM_CP = d("cp_cost", 400, 0, 100000);
    public static final DoubleValue KM_OVERLOAD = d("overload_cost", 100, 0, 10000);
    public static final DoubleValue KM_COOLDOWN = sec("cooldown_seconds", 60, 3600);
    public static final DoubleValue KM_CHARGE = sec("charge_seconds", 1.5, 10);
    public static final DoubleValue KM_BEAM_DURATION = sec("beam_duration_seconds", 2.0, 10);
    public static final DoubleValue KM_RANGE = d("beam_range", 24.0, 4.0, 96.0);
    public static final DoubleValue KM_RADIUS = d("beam_radius", 1.5, 0.5, 5.0);
    public static final DoubleValue KM_DAMAGE = d("damage_per_tick", 6.0, 0, 1000);
    public static final DoubleValue KM_TICK_RATE = sec("damage_tick_rate", 0.2, 1.0);
    public static final DoubleValue KM_KNOCKBACK = d("knockback", 1.5, 0, 10);
    public static final ConfigValue<Boolean> KM_AFFECT_PLAYERS = B.define("affect_players", true);
    public static final ConfigValue<Boolean> KM_AFFECT_ALLIES = B.define("affect_allies", false);
    public static final ConfigValue<Boolean> KM_AFFECT_CASTER = B.define("affect_caster", false);
    public static final ConfigValue<Boolean> KM_PIERCING = B.define("piercing", true);

    static { B.pop(); }
    public static final ForgeConfigSpec SPEC = B.build();
    public static float f(DoubleValue v) { return v.get().floatValue(); }
    public static int ticks(DoubleValue seconds) { return Math.max(1, (int) Math.round(seconds.get() * 20.0)); }
    public static boolean b(ConfigValue<Boolean> v) { return Boolean.TRUE.equals(v.get()); }
}