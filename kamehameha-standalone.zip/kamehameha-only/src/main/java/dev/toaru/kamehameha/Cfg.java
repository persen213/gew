package dev.toaru.kamehameha;

import java.util.List;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.common.ForgeConfigSpec.ConfigValue;
import net.minecraftforge.common.ForgeConfigSpec.DoubleValue;

/** Server-authoritative balance settings in kamehameha-common.toml. */
public final class Cfg {
    private Cfg() { }
    private static final ForgeConfigSpec.Builder B = new ForgeConfigSpec.Builder();
    private static DoubleValue d(String name, double def, double min, double max) { return B.defineInRange(name, def, min, max); }
    private static DoubleValue sec(String name, double def, double max) { return d(name, def, 0.05, max); }
    private static void push(String name, String comment) { B.comment(comment).push(name); }

    static { push("kamehameha", "Kamehameha beam ability. All gameplay values are server-side and configurable."); }
    public static final DoubleValue KM_CP = d("cp_cost", 400, 0, 100000);
    public static final DoubleValue KM_OVERLOAD = d("overload_cost", 100, 0, 10000);
    public static final DoubleValue KM_COOLDOWN = sec("cooldown_seconds", 60, 3600);
    public static final DoubleValue KM_CHARGE = sec("charge_seconds", 1.5, 10);
    public static final DoubleValue KM_BEAM_DURATION = sec("beam_duration_seconds", 2.0, 10);
    public static final DoubleValue KM_RANGE = d("beam_range", 24.0, 4.0, 96.0);
    public static final DoubleValue KM_RADIUS = d("beam_radius", 1.5, 0.5, 5.0);
    public static final DoubleValue KM_DAMAGE = d("damage_per_tick", 6.0, 0, 1000);
    public static final DoubleValue KM_TICK_RATE = sec("damage_tick_rate", 0.2, 1.0);
    public static final DoubleValue KM_KNOCKBACK = d("knockback", 1.5, 0, 10);
    public static final ConfigValue<Boolean> KM_AFFECT_PLAYERS = B.define("affect_players", true);
    public static final ConfigValue<Boolean> KM_AFFECT_ALLIES = B.define("affect_allies", false);
    public static final ConfigValue<Boolean> KM_AFFECT_CASTER = B.define("affect_caster", false);
    public static final ConfigValue<Boolean> KM_PIERCING = B.define("piercing", true);

    static { B.pop(); }
    public static final ForgeConfigSpec SPEC = B.build();
    public static float f(DoubleValue v) { return v.get().floatValue(); }
    public static int ticks(DoubleValue seconds) { return Math.max(1, (int) Math.round(seconds.get() * 20.0)); }
    public static boolean b(ConfigValue<Boolean> v) { return Boolean.TRUE.equals(v.get()); }
}