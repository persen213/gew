package dev.toaru.kamehameha.client;

import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.toaru.kamehameha.Kamehameha;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;

@Mod.EventBusSubscriber(modid = Kamehameha.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class WorldRenderer {
    private WorldRenderer() { }

    private static MultiBufferSource.BufferSource buffers;

    private static MultiBufferSource.BufferSource buffers() {
        if (buffers == null) {
            Map<RenderType, BufferBuilder> fixed = new HashMap<>();
            fixed.put(MoRenderTypes.GLOW, new BufferBuilder(1 << 20));
            buffers = MultiBufferSource.immediateWithBuffers(fixed, new BufferBuilder(256));
        }
        return buffers;
    }

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;
        if (ClientFx.ACTIVE.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        float partial = mc.isPaused() ? 0f : event.getPartialTick();
        long now = mc.level.getGameTime();
        double time = now + partial;
        Camera camera = event.getCamera();
        Vec3 cam = camera.getPosition();
        PoseStack stack = event.getPoseStack();
        Matrix4f pose = stack.last().pose();
        MultiBufferSource.BufferSource src = buffers();

        VertexConsumer glow = src.getBuffer(MoRenderTypes.GLOW);

        Geo geoGlow = new Geo(glow, pose, cam);

        FxRenderer.draw(geoGlow, camera, now, partial, time);

        src.endBatch(MoRenderTypes.GLOW);
    }
}