package dev.toaru.kamehameha;

import com.mojang.logging.LogUtils;
import dev.toaru.kamehameha.net.Net;
import dev.toaru.kamehameha.skills.KamehamehaSkill;
import io.github.pinchan4273.reacademycraft.api.AbilityId;
import io.github.pinchan4273.reacademycraft.api.ActivationKind;
import io.github.pinchan4273.reacademycraft.api.CategoryDefinition;
import io.github.pinchan4273.reacademycraft.api.Presentation;
import io.github.pinchan4273.reacademycraft.api.SkillDefinition;
import io.github.pinchan4273.reacademycraft.api.TreePosition;
import io.github.pinchan4273.reacademycraft.api.forge.RegisterAbilitiesEvent;
import java.util.List;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

/**
 * Kamehameha: a single signature move — a cinematic energy beam.
 * Re:AcademyCraft checks learned, CP/overload, cooldown; the skill validates target, pays, works, sets cooldown.
 */
@Mod(Kamehameha.MOD_ID)
public final class Kamehameha {
    public static final String MOD_ID = "kamehameha";
    public static final Logger LOGGER = LogUtils.getLogger();

    public static AbilityId id(String path) { return AbilityId.parse(MOD_ID + ":" + path); }

    public static final AbilityId CATEGORY = id("energy_beam");
    public static final AbilityId KAMEHAMEHA = id("kamehameha");

    public Kamehameha() {
        var bus = FMLJavaModLoadingContext.get().getModEventBus();
        bus.addListener(this::commonSetup);
        bus.addListener(this::registerAbilities);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, Cfg.SPEC);
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, ClientCfg.SPEC);
    }

    private void commonSetup(FMLCommonSetupEvent event) { event.enqueueWork(Net::register); }

    private static AbilityId icon(String name) { return AbilityId.parse(MOD_ID + ":textures/abilities/kamehameha/" + name + ".png"); }

    private static Presentation shown(AbilityId skill) {
        return new Presentation(MOD_ID + ".skill." + skill.path(), MOD_ID + ".skill." + skill.path() + ".desc", icon(skill.path()));
    }

    private void registerAbilities(RegisterAbilitiesEvent event) {
        var r = event.registrar(MOD_ID);
        r.category(new CategoryDefinition(CATEGORY, null, List.of(1, 1, 1, 1, 1),
                new Presentation(MOD_ID + ".ability." + CATEGORY.path(), null, icon(CATEGORY.path()))));
        r.skill(new SkillDefinition(KAMEHAMEHA, CATEGORY, 1, List.of(),
                ActivationKind.INSTANT, shown(KAMEHAMEHA), new TreePosition(120, 58, null)));

        var b = event.behaviors(MOD_ID);
        b.behavior(KAMEHAMEHA, new KamehamehaSkill());
    }
}