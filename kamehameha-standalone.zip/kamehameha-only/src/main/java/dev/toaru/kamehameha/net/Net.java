package dev.toaru.kamehameha.net;

import dev.toaru.kamehameha.Kamehameha;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class Net {
    private Net() { }
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(Kamehameha.MOD_ID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);
    private static boolean registered;

    public static synchronized void register() {
        if (registered) return;
        registered = true;
        int id = 0;
        CHANNEL.registerMessage(id++, FxStartMsg.class, FxStartMsg::encode, FxStartMsg::decode, FxStartMsg::handle);
        CHANNEL.registerMessage(id++, AnimMsg.class, AnimMsg::encode, AnimMsg::decode, AnimMsg::handle);
    }
}