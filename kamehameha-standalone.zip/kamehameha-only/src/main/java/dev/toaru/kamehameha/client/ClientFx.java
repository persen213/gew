package dev.toaru.kamehameha.client;

import dev.toaru.kamehameha.net.FxStartMsg;
import dev.toaru.kamehameha.net.FxType;
import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/** Running visual effects on this client: plain data, drawn by WorldRenderer, removed when their time is up (capped). */
public final class ClientFx {
    private ClientFx() { }

    private static final int MAX = 128;
    static final Map<Long, Effect> ACTIVE = new LinkedHashMap<>();

    public static final class Effect {
        public final long key;
        public final FxType type;
        public final long start;
        public final int duration;
        public final Vec3 pos, aux;
        public final int a, b, c;
        public final float power;
        /** Recent positions of the caster (newest first), only for trails. */
        final ArrayDeque<Vec3> trail = new ArrayDeque<>();

        Effect(FxStartMsg m, long start) {
            this.key = m.key; this.type = m.type; this.start = start; this.duration = m.duration;
            this.pos = new Vec3(m.x, m.y, m.z); this.aux = new Vec3(m.ax, m.ay, m.az);
            this.a = m.a; this.b = m.b; this.c = m.c; this.power = m.power;
        }

        public double age(long now, float partial) { return (now - start) + partial; }

        public boolean live(long now) { return now - start <= duration; }
    }

    public static void start(FxStartMsg msg) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        ACTIVE.put(msg.key, new Effect(msg, mc.level.getGameTime()));
        if (ACTIVE.size() > MAX) {
            Iterator<Long> it = ACTIVE.keySet().iterator();
            it.next();
            it.remove();
        }
    }

    public static void cancel(long key) { ACTIVE.remove(key); }

    /** True if an effect of this type cast by this entity is running. */
    public static Effect of(int entity, FxType type) {
        Effect best = null;
        for (Effect e : ACTIVE.values()) if (e.type == type && e.a == entity && (best == null || e.start >= best.start)) best = e;
        return best;
    }

    public static void clear() { ACTIVE.clear(); }

    public static void tick() {
        if (ACTIVE.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) { ACTIVE.clear(); return; }
        long now = mc.level.getGameTime();
        ACTIVE.values().removeIf(e -> now - e.start > e.duration + 2 || now < e.start - 40);
    }
}