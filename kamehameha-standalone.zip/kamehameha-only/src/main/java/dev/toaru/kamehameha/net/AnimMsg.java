package dev.toaru.kamehameha.net;

import dev.toaru.kamehameha.client.ClientNet;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

public final class AnimMsg {
    public final int entityId;
    public final int anim;

    public AnimMsg(int entityId, int anim) { this.entityId = entityId; this.anim = anim; }

    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(entityId);
        buf.writeInt(anim);
    }

    public static AnimMsg decode(FriendlyByteBuf buf) {
        return new AnimMsg(buf.readInt(), buf.readInt());
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientNet.anim(entityId, anim)));
        c.setPacketHandled(true);
    }
}