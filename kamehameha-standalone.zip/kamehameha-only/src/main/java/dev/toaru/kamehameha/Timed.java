package dev.toaru.kamehameha;

import io.github.pinchan4273.reacademycraft.api.mc.AbilityActor;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Predicate;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

/** Timed effects ticked each server tick. */
public final class Timed {
    private Timed() { }

    public abstract static class Effect {
        public final ServerPlayer owner;
        public final AbilityActor actor;
        public final ServerLevel level;
        public final long started;
        public long end;
        boolean dead;

        protected Effect(ServerPlayer owner, AbilityActor actor, int ticks) {
            this.owner = owner; this.actor = actor; this.level = owner.serverLevel();
            this.started = level.getGameTime(); this.end = started + ticks;
        }

        public long age() { return level.getGameTime() - started; }
        public boolean over() { return level.getGameTime() >= end; }
        public boolean ended() { return dead; }
        protected abstract boolean tick();
        protected void end(boolean natural) { }
    }

    private static final List<Effect> ALL = new ArrayList<>();
    private static final List<Effect> ADDED = new ArrayList<>();

    public static <T extends Effect> T add(T e) { ADDED.add(e); return e; }
    public static boolean any() { return !ALL.isEmpty() || !ADDED.isEmpty(); }

    @SuppressWarnings("unchecked")
    public static <T extends Effect> List<T> of(Class<T> type) {
        List<T> out = new ArrayList<>();
        for (Effect e : ALL) if (!e.dead && type.isInstance(e)) out.add((T) e);
        for (Effect e : ADDED) if (!e.dead && type.isInstance(e)) out.add((T) e);
        return out;
    }

    public static <T extends Effect> T ownedBy(Class<T> type, UUID owner) {
        for (T e : of(type)) if (e.owner.getUUID().equals(owner)) return e;
        return null;
    }

    private static boolean ownerOk(Effect e) { return !e.owner.isRemoved() && e.owner.isAlive() && e.owner.level() == e.level; }

    public static void tick() {
        if (!ADDED.isEmpty()) { ALL.addAll(ADDED); ADDED.clear(); }
        for (Effect e : new ArrayList<>(ALL)) {
            if (e.dead) continue;
            boolean keep;
            try { keep = ownerOk(e) && e.tick(); }
            catch (RuntimeException ex) { Kamehameha.LOGGER.error("Kamehameha: effect failed", ex); keep = false; }
            if (!keep && !e.dead) { e.dead = true; safeEnd(e, ownerOk(e)); }
        }
        ALL.removeIf(x -> x.dead);
        ADDED.removeIf(x -> x.dead);
    }

    public static void removeOwner(UUID owner) { remove(e -> e.owner.getUUID().equals(owner), false); }
    public static void remove(Predicate<Effect> which, boolean natural) {
        List<Effect> hit = new ArrayList<>();
        for (Effect e : ALL) if (!e.dead && which.test(e)) hit.add(e);
        for (Effect e : ADDED) if (!e.dead && which.test(e)) hit.add(e);
        for (Effect e : hit) { e.dead = true; safeEnd(e, natural); }
    }
    public static void stop(Effect e, boolean natural) { remove(x -> x == e, natural); }
    public static void clear() { remove(e -> true, false); ALL.clear(); ADDED.clear(); }
    private static void safeEnd(Effect e, boolean natural) { try { e.end(natural); } catch (RuntimeException ex) { Kamehameha.LOGGER.error("Kamehameha: effect failed to end", ex); } }
}