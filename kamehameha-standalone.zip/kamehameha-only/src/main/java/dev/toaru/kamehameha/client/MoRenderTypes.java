package dev.toaru.kamehameha.client;

import net.minecraft.client.renderer.RenderType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterClientReloadListenersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Custom render types for Kamehameha visuals. */
@Mod.EventBusSubscriber(modid = "kamehameha", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class MoRenderTypes {

    /** Additive glow (beam, charge) - uses vanilla lightning */
    public static final RenderType GLOW = RenderType.lightning();

    @SubscribeEvent
    public static void onRegisterReloadListeners(RegisterClientReloadListenersEvent event) {
        // Register reload listener to recreate buffers if needed
    }
}