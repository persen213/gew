package dev.toaru.kamehameha;

import javax.annotation.Nullable;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.common.ForgeConfigSpec.DoubleValue;

/** Resistance calculations for Kamehameha. */
public final class Resist {
    private Resist() { }

    public static boolean immune(LivingEntity t) {
        String tag = Cfg.IMMUNE_TAG.get();
        return t instanceof ServerPlayer && tag != null && !tag.isEmpty() && t.getTags().contains(tag);
    }

    public static boolean electro(LivingEntity t) {
        if (!(t instanceof ServerPlayer p)) return false;
        String cat = AcBridge.category(p);
        return cat != null && Cfg.ELECTRO_CATEGORIES.get().contains(cat);
    }

    public static boolean vector(LivingEntity t) {
        if (!(t instanceof ServerPlayer p)) return false;
        String cat = AcBridge.category(p);
        return cat != null && Cfg.VEC_CATEGORIES.get().contains(cat);
    }

    public static boolean boss(LivingEntity t) { return !(t instanceof ServerPlayer) && Targeting.bossLike(t); }

    public static int level(LivingEntity t) { return t instanceof ServerPlayer p ? Math.max(0, AcBridge.level(p)) : 0; }

    public static double factor(LivingEntity t) {
        if (immune(t)) return 0;
        if (t instanceof ServerPlayer) {
            double k = Math.max(Cfg.PLAYER_MIN_FACTOR.get(), 1.0 - Cfg.PLAYER_LEVEL_RESIST.get() * level(t));
            if (electro(t)) k *= Cfg.ELECTRO_FACTOR.get();
            if (vector(t)) k *= Cfg.VEC_FACTOR.get();
            return k;
        }
        if (Targeting.bossLike(t)) return Cfg.BOSS_FACTOR.get();
        return t.getMaxHealth() >= Cfg.STRONG_MOB_HEALTH.get() ? Cfg.STRONG_MOB_FACTOR.get() : 1.0;
    }

    public static double pullFactor(LivingEntity t) {
        if (vector(t)) return 0.0;
        if (electro(t)) return Cfg.ELECTRO_FACTOR.get();
        return factor(t);
    }

    public static double damageFactor(LivingEntity t) {
        if (vector(t)) return 0.0;
        if (electro(t)) return Cfg.ELECTRO_FACTOR.get();
        return factor(t);
    }
}