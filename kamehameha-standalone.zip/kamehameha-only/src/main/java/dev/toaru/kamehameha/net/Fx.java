package dev.toaru.kamehameha.net;

import dev.toaru.kamehameha.Kamehameha;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

/** Builder for visual effect packets. */
public final class Fx {
    private Fx() { }

    private static long NEXT_KEY = 1;

    public static Builder make(ServerLevel level, Vec3 pos, FxType type, int duration) {
        return new Builder(level, pos, type, duration);
    }

    public static void cancel(ServerLevel level, long key) {
        // Could send cancel if needed, but effects auto-expire
    }

    /** Sends a hint above the hotbar. */
    public static void hint(ServerPlayer p, String text) {
        p.displayClientMessage(Component.literal("§7" + text), true);
    }

    public static final class Builder {
        private final ServerLevel level;
        private final Vec3 pos;
        private final FxType type;
        private final int duration;
        private Vec3 aux = Vec3.ZERO;
        private int a = 0, b = 0, c = 0;
        private float power = 1.0f;
        private double range = 96.0;

        Builder(ServerLevel level, Vec3 pos, FxType type, int duration) {
            this.level = level; this.pos = pos; this.type = type; this.duration = Math.max(1, duration);
        }

        public Builder aux(Vec3 v) { this.aux = v; return this; }
        public Builder a(int v) { this.a = v; return this; }
        public Builder b(int v) { this.b = v; return this; }
        public Builder c(int v) { this.c = v; return this; }
        public Builder range(double v) { this.range = v; return this; }
        public Builder power(float v) { this.power = v; return this; }

        private FxStartMsg build(long key) {
            return new FxStartMsg(key, type, duration, pos.x, pos.y, pos.z, aux.x, aux.y, aux.z, a, b, c, power, 0L);
        }

        public void send() {
            long key = NEXT_KEY++;
            FxStartMsg msg = build(key);
            ResourceKey<net.minecraft.world.level.Level> dim = level.dimension();
            Net.CHANNEL.send(PacketDistributor.NEAR.with(
                    () -> new PacketDistributor.TargetPoint(pos.x, pos.y, pos.z, range, dim)), msg);
        }

        public void sendTo(ServerPlayer p) {
            long key = NEXT_KEY++;
            Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), build(key));
        }
    }
}