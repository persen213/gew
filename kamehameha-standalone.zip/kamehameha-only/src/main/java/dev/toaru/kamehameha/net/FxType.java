package dev.toaru.kamehameha.net;

/** Visual effect types for Kamehameha. */
public enum FxType {
    /** Charging energy at caster's hands */
    KAMEHAMEHA_CHARGE,
    /** Active beam projectile */
    KAMEHAMEHA_BEAM,
}